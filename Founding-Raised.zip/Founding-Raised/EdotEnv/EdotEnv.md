# EdotEnv (Y S26)

- THis is the company to raised found at y-combinator, his linkedin page nothing are found only discription have.

![y-combinator linkedin post](<assets/Screenshot 2026-08-14 135500.png>)

![home linked page](<assets/Screenshot 2026-08-14 150144.png>)
![about linked page](<assets/Screenshot 2026-08-14 150126.png>)

![Posts linked page](<assets/Screenshot 2026-08-14 150104.png>)
![People linked page](<assets/Screenshot 2026-08-14 150048.png>)


## his website. 
# [home-page approach](assets/approach.pdf)

# [Blog-page](assets/blog.pdf)
[first-blog-page](assets/first-blog.pdf)

[second-blog-page](assets/second-blog.pdf)

# [team-page](assets/team.pdf)

# [news-page](assets/news-page.pdf)
[first-news](assets/first-news.pdf)

[second-news](assets/second-news.pdf)


