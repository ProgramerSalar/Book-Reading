# Example of small company raised pre-seed round.

- there are two small company example to raise pre-seed found at y-combinator. 
in these company folder all those things have found at starting. like how was company website, linkedin. product. at starting phase.