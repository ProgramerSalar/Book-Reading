# parasma

- This is the company to build model to connect human mind. 

![home-page linkedin](<assets/Screenshot 2026-08-14 230052.png>)
![about-page linkedin](<assets/Screenshot 2026-08-14 230105.png>)
![post-page linkedin](<assets/Screenshot 2026-08-14 230125.png>)

- website.
## [home-page](assets/home-page.pdf)
## [research-page](assets/research-page.pdf)

## [News-page](assets/news-page.pdf)
## [News-page two](assets/new-page-two.pdf)

## [about-page](assets/about-page.pdf)


# x
![first-post](<assets/Screenshot 2026-08-14 231134.png>)

